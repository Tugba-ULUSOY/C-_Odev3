#include<iostream>
#include<cstdlib>
#include<locale.h>
#include<string>
using namespace std;

struct cuml  // yap� tan�mla
{
	string cumle1;  //yap� �ye de�i�keni
	string kelime;  //yap� �ye de�i�keni
	};  //yap� tan�mlama (;) ile biter
void fonk1(struct cuml cumle)
{
	int sayac = 0;  // sayac de�i�kenini tan�mla ve de�er de�er ata
	for (int i = 0; i < (cumle.cumle1).length(); i++)  // D�ng� c�mle ba��ndan sonuna kadar
	{
		if ((cumle.cumle1).at(i) != ' ' && (cumle.cumle1).at(i) >= 65)  // e�er girilen ifade bo�lu�a e�it de�ilse ve ASCII tablosundaki de�eri 65 den b�y�kse 
			sayac++;  // sayac� 1 art�r
	}
	int i = 0;
		if (((cumle.cumle1).at(i) < 32 && (cumle.cumle1).at(i) > 47) || ((cumle.cumle1).at(i) < 58 && (cumle.cumle1).at(i) > 64) || ((cumle.cumle1).at(i) < 91 && (cumle.cumle1).at(i) > 96) || ((cumle.cumle1).at(i) < 123 && (cumle.cumle1).at(i) > 126))  //e�er girilen ifade ASCII tablosundaki bu de�er aral�klar�ndaki ko�ullar� sa�l�yorsa
	{
		sayac = 0;  // sayac� art�rma
	}
	cout<<"cumledeki harf sayisi   : "<< sayac<<endl;  // c�mledeki harf say�s� ekrana getirilir
}
void fonk2(struct cuml cumle)
{
	int sayac = 0; // sayac de�i�kenini tan�mla ve de�er de�er ata
	for (int i = 0; i < (cumle.cumle1).length(); i++) // D�ng� c�mle ba��ndan sonuna kadar
	{
		if ((cumle.cumle1).at(i) == ' ' ) // e�er girilen ifade bo�lu�a e�itse 
			sayac++;  // sayac� 1 art�r
	}
	cout << "cumledeki kelime sayisi     :" << sayac +1<<endl;  // sayac�n 1 art�r�lm�� hali c�mledeki kelime say�s� olarak ekrana girilir
}
void fonk3(struct cuml cumle)
{
	for (int i = 0; i < (cumle.cumle1).length(); i++)
	{
		if (((cumle.cumle1).at(i) >=33 && (cumle.cumle1).at(i) <=47 ) || ((cumle.cumle1).at(i) >=58 && (cumle.cumle1).at(i) <=64 )||((cumle.cumle1).at(i) >=91) && ((cumle.cumle1).at(i) <=96 ) || ((cumle.cumle1).at(i) >=123) && ((cumle.cumle1).at(i) <= 126 )) // e�er ASCII tablosundaki de�er aral���n� sa�l�yorsa
		cout << "cumledeki isaretler       :" << cumle.cumle1[i] << endl;  // girilen ifadedeki i�aretler ekrana getirilir
	}
}
void fonk4(struct cuml cumle)
{
	if ((cumle.cumle1) == string((cumle.cumle1).rbegin(), (cumle.cumle1).rend()))
		cout << "cumle palindromdur" << endl;
}
void fonk5(struct cuml cumle)
{
	int sayac = 0; 
	for (int i = 0; i < (cumle.cumle1).length(); i++) // D�ng� c�mle ba��ndan sonuna kadar
	{
		if ((cumle.cumle1[i] == ' ')||((cumle.cumle1).at(i) >= 33 && (cumle.cumle1).at(i) <= 47) || ((cumle.cumle1).at(i) >= 58 && (cumle.cumle1).at(i) <= 64) || ((cumle.cumle1).at(i) >= 91) && ((cumle.cumle1).at(i) <= 96) || ((cumle.cumle1).at(i) >= 123) && ((cumle.cumle1).at(i) <= 126)) // e�er ASCII de�er aral���n� sa�l�yorsa
		{
			cout << "cumledeki kelimelerin harf sayisi  : " << sayac<<endl;
				sayac =-1;
		}
			sayac++ ;
	}
	cout << "cumledeki kelimelerin harf sayisi  :  " << sayac << endl;
}
void fonk6(struct cuml cumle)
{
	int sayac = 0;
	for (int i = 0; i < (cumle.cumle1).length(); i++) // D�ng� c�mle ba��ndan sonuna kadar
	{
		if (cumle.cumle1[i] != ' ') 
		{
			if ((cumle.cumle1[i]) == 'a' || (cumle.cumle1[i]) == '�'|| (cumle.cumle1[i]) == 'i' || (cumle.cumle1[i]) == 'u' || (cumle.cumle1[i]) == 'o')
				sayac++; 
		}
		else  
		{
			cout << "cumledeki sesli harflerin sayisi   :" << sayac << endl;
			sayac = 0; 
		}
	}

	cout << "cumledeki sesli harflerin sayisi   :" << sayac << endl;
	}
void fonk7(struct cuml cumle)
{

}
int main(int argc, char*argv[])
{
	setlocale(LC_ALL, "turkish");
	struct cuml cumle;
	getline(cin, (cumle.cumle1));
	fonk1(cumle);
	fonk2(cumle);
	fonk3(cumle);
	fonk4(cumle);
	fonk5(cumle);
	fonk6(cumle);
	system("PAUSE");
	return 0;
}